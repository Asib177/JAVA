import src.Student;
import src.Facalty;
import src.Course;
import java.util.*;
import java.io.*;

public class Main {
    private static final String ANSI_RESET = null;
    public static ArrayList<Student> students = new ArrayList<Student>();
    public static ArrayList<Facalty> facalties = new ArrayList<Facalty>();
    public static ArrayList<Course> courses = new ArrayList<Course>();
    public static Scanner input = new Scanner(System.in);

    public static void addStudent() {
        System.out.println("Name: ");
        String n = input.nextLine();
        input.nextLine();
        System.out.println("ID: ");
        int id = input.nextInt();
        System.out.println("CGPA: ");
        double cg = input.nextDouble();
        Student s = new Student(id, n, cg);
        boolean flag = false;
        for (Student e : students) {
            if (e.getStudentId() == s.getStudentId()) {
                flag = true;
                break;
            }
        }
        if (flag) {
            System.out.println("Student already exists. Try Again!");
        } else {
            students.add(s);
            System.out.println("Student added successfully!");
        }
    }

    public static void addCourse() {
        System.out.println("ID: ");
        String id = input.nextLine();
        input.nextLine();
        System.out.println("Title: ");
        String t = input.nextLine();
        System.out.println("Cradit: ");
        double crd = input.nextDouble();
        Course c = new Course(id, t, crd);

        boolean flag = false;
        for (Course e : courses) {
            if (e.getCourseId().equals(c.getCourseId())) {
                flag = true;
                break;
            }
        }
        if (flag) {
            System.out.println("Course already exist. Try Again!");
        } else {
            courses.add(c);
            System.out.println("Coursr added successfully.");
        }
    }

    public static void addFacalty() {
        System.out.println("ID: ");
        int id = input.nextInt();
        System.out.println("Name: ");
        String n = input.nextLine();
        input.nextLine();
        System.out.println("Position: ");
        String p = input.nextLine();
        Facalty f = new Facalty(id, n, p);

        boolean flag = false;
        for (Facalty e : facalties) {
            if (e.getFacultyId() == f.getFacultyId()) {
                flag = true;
                break;
            }
        }
        if (flag) {
            System.out.println("Facalty already exist. Try Again!");
        } else {
            facalties.add(f);
            System.out.println("Facalty added successfully.");
        }
    }

    public static void addStudentCourse() {
        System.out.println("Enter the course ID: ");
        String cid = input.nextLine();
        input.nextLine();
        System.out.println("Enter the student ID: ");
        int sid = input.nextInt();

        int courseIndex = -1;
        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).getCourseId().equals(cid)) {
                courseIndex = i;
                break;
            }
        }
        int studentIndex = -1;
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getStudentId() == sid) {
                studentIndex = i;
                break;
            }
        }

        if (courseIndex == -1 || studentIndex == -1) {
            System.out.println("Invalid course or student.!");
        } else {
            courses.get(courseIndex).addStudent(students.get(studentIndex));
            System.out.println("Student added course successfully.");
        }
    }

    public static void addFacaltyCourse() {
        System.out.println("Enter the course ID: ");
        String cid = input.nextLine();
        input.nextLine();
        System.out.println("Enter the Facalty ID: ");
        int fid = input.nextInt();

        int courseIndex = -1;
        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).getCourseId().equals(cid)) {
                courseIndex = i;
                break;
            }
        }
        int facaltyIndex = -1;
        for (int i = 0; i < facalties.size(); i++) {
            if (facalties.get(i).getFacultyId() == fid) {
                facaltyIndex = i;
                break;
            }
        }
        if (courseIndex == -1 || facaltyIndex == -1) {
            System.out.println("Invalid course or Facalty.!");
        } else {
            courses.get(courseIndex).addFacalty(facalties.get(facaltyIndex));
            System.out.println("Facalty added of course successfully.");
        }
    }

    public static void deleteStudent() {

    }

    public static void deleteCourse() {

    }

    public static void deleteFacalty() {

    }

    public static void updateStudent() {

    }

    public static void updateCourse() {

    }

    public static void updateFacalty() {

    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("a. Add\nb. Delete\nc. Update\nd. Print\ne. Search\nf. Exit");
            char ch = input.next().charAt(0);
            if (ch == 'f') {
                break;
            } else if (ch == 'a') {
                System.out.println(
                        "1. Add a Student\n2. Add a Course\n3. Add a Facalty\n4. Add a student to a course\n5. Add a faculty to a course\n0. Return to main menu");
                int x = input.nextInt();
                if (x == 0) {
                    continue;
                } else if (x == 1) {
                    addStudent();
                } else if (x == 2) {
                    addCourse();
                } else if (x == 3) {
                    addFacalty();
                } else if (x == 4) {
                    addStudentCourse();
                } else if (x == 5) {
                    addFacaltyCourse();
                }
            } else if (ch == 'b') {
                System.out.println(
                        "1. Delete a Student\n2. Delete a Course\n3. Delete a Facalty\n4. Delete a student to a course\n5. Delete a faculty to a course\n0. Return to main menu");
                int x = input.nextInt();
                if (x == 0) {
                    continue;
                } else if (x == 1) {
                    deleteStudent();
                } else if (x == 2) {
                    deleteCourse();
                } else if (x == 3) {
                    deleteFacalty();
                } else if (x == 4) {
                    // deleteStudentCourse();
                } else if (x == 5) {
                    // deleteFacaltyCourse();
                }
            } else if (ch == 'c') {
                System.out.println(
                        "1. Update a Student\n2. Update a Course\n3. Update a Facalty\n4. Update a student to a course\n5. Update a faculty to a course\n0. Return to main menu");
                int x = input.nextInt();
                if (x == 0) {
                    continue;
                } else if (x == 1) {
                    updateStudent();
                } else if (x == 2) {
                    updateCourse();
                } else if (x == 3) {
                    updateFacalty();
                } else if (x == 4) {
                    // updateStudentCourse();
                } else if (x == 5) {
                    // updateFacaltyCourse();
                }
            } else if (ch == 'd') {
                System.out.println(
                        "1. Print all students\n2. Print all courses\n3. Print all faculties\n4. Print information of a student\n5. Print information of a course\n6. Print information of a faculty\n7. Print student list and faculty information of a course\n8. Print courses taken by a student\n0. Return main menu");
                int x = input.nextInt();
                if (x == 0) {
                    continue;
                } else if (x == 1) {
                    for (Student e : students) {
                        final String ANSI_RESET = "\u001B[0m";
                        final String ANSI_RED_BACKGROUND = "\u001B[41m";
                        System.out.println((ANSI_RED_BACKGROUND + e.toString() + ANSI_RESET));
                    }
                } else if (x == 2) {
                    for (Course e : courses) {
                        final String ANSI_RESET = "\u001B[0m";
                        final String ANSI_RED_BACKGROUND = "\u001B[41m";
                        System.out.println((ANSI_RED_BACKGROUND + e.toString() + ANSI_RESET));
                    }
                } else if (x == 3) {
                    for (Facalty e : facalties) {
                        final String ANSI_RESET = "\u001B[0m";
                        final String ANSI_RED_BACKGROUND = "\u001B[41m";
                        System.out.println((ANSI_RED_BACKGROUND + e.toString() + ANSI_RESET));
                    }
                } else if (x == 4) {
                    int sid = input.nextInt();
                    for (Student e : students) {
                        if (e.getStudentId() == sid) {
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + e.toString() + ANSI_RESET));
                        }
                    }
                } else if (x == 5) {
                    String cid = input.next();
                    for (Course e : courses) {
                        if (e.getCourseId() == cid) {
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + e.toString() + ANSI_RESET));
                        }
                    }
                } else if (x == 6) {
                    int fid = input.nextInt();
                    for (Facalty e : facalties) {
                        if (e.getFacultyId() == fid) {
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + e.toString() + ANSI_RESET));
                        }
                    }
                } else if (x == 7) {
                    System.out.println("Enter the course ID: ");
                    String cid = input.next();
                    for (Course e : courses) {
                        if (e.getCourseId().equals(cid)) {
                            e.peintStudentList();
                        }
                    }
                } else if (x == 8) {

                }
            } else if (ch == 'e') {
                System.out.println(
                        "a. Search a Student\nb. Search a Course\nc. Search a Faculty\nd. Search whether a student takes a course\ne. Search whether a faculty teaches a course\nf. Search courses taken by a student\ng. Search courses taught by a faculty\nz. Return main menu");
                char x = input.next().charAt(0);
                if (x == 'z') {
                    continue;
                } else if (x == 'a') {
                    int sid = input.nextInt();
                    for (Student e : students) {
                        if (sid == e.getStudentId()) {
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + "Student Match" + ANSI_RESET));
                        }
                        else{
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + "Student doesn't Match" + ANSI_RESET));
                        }
                    }
                } else if (x == 'b') {
                    String cid = input.next();
                    for (Course e : courses) {
                        if (cid == e.getCourseId()) {
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + "Course Match" + ANSI_RESET));
                        }
                        else{
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + "Course doesn't Match" + ANSI_RESET));
                        }
                    }
                } else if (x == 'c') {
                    int fid = input.nextInt();
                    for (Facalty e : facalties) {
                        if (fid == e.getFacultyId()) {
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + "Facalty Match" + ANSI_RESET));
                        }
                        else{
                            final String ANSI_RESET = "\u001B[0m";
                            final String ANSI_RED_BACKGROUND = "\u001B[41m";
                            System.out.println((ANSI_RED_BACKGROUND + "Facalty doesn't Match" + ANSI_RESET));
                        }
                    }
                } else if (x == 'd') {

                } else if (x == 'e') {

                } else if (x == 'f') {

                } else if (x == 'g') {

                }
            }
        }
    }
}
